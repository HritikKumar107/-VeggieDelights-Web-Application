import {db} from './Firebase'
import {useState, useEffect} from 'react'
import {collection, query, orderBy, onSnapshot, Timestamp,doc, deleteDoc} from "firebase/firestore"
import { Link } from 'react-router-dom'

export default function ManageCategory(){

    const [allTask , setTask] = useState([])
    useEffect(() => {
        const que = query(collection (db, 'Category'),orderBy('created','asc'))
        onSnapshot(que,(querySnapshot) => {
            setTask(querySnapshot.docs.map(doc => ({
                id : doc.id,
                data : doc.data()
            })))
        })
    },[])

    const getdate = (datetime) =>{
        const date = (datetime.toDate().toString())
        const S = date.split(' ');
        console.log(S)
        const returndate = S[2]+"-"+S[1]+"-"+S[3]
        return returndate
    }

    const handleDelete = async (id) => {
        const taskDocRef = doc(db, 'Category', id)
        try{
          await deleteDoc(taskDocRef)
        } catch (err) {
          alert(err)
        }
      }


    return(
        <>
        <div className="container-fluid page-header wow fadeIn" data-wow-delay="0.1s">
            <div className="container text-center">
                <div className="section-header text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style={{'maWidth': '500px'}}>
                    <h1 className="display-3 animated slideInDown" style={{ 'textShadow': '5px 7px 5px rgb(190, 190, 190)'}}>Manage Category</h1>
                </div>
            </div>
        </div>

        <div className="viewtable container-fluid my-5">
            <table class="table table-bordered border-dark table-responsive">
                <thead className="table-dark">
                    <tr>
                        <td>Id</td>
                        <td>Category Name</td>
                        <td>Images</td>
                        <td>Status</td>
                        <td>Created At</td>
                        <td>Action</td>
                    </tr>
                </thead>
                <tbody>
                    {allTask.map((category,index) =>(
                        <tr>
                        <td>{index+1}</td>
                        <td>{category.data.categoryname}</td>
                        <td>
                            <img className='form-img' src={category.data.Image}
                            width={'200px'}></img>
                        </td>
                        <td>{category.data.taskcompletionStatus}</td>
                        <td>{getdate(category.data.created)}</td>
                        <td>
                            <i className="fa fa-edit text-success fa-2x" style={{'alignItems':'start','justifyContent':'start'}}>&nbsp;</i>
                            <a onClick={() => {
                                const confirmBox = window.confirm(
                                "Do you really want to delete this?"
                                )
                                if (confirmBox == true) {
                                    // alert(confirmBox)
                                handleDelete(category.id)
                                }
                            }}><i className="fa fa-trash text-danger fa-2x" style={{'alignItems':'end','justifyContent':'end'}}>&nbsp;</i></a>
                        </td>
                    </tr>
                    ))}
                </tbody>
            </table>
        </div>
        </>
    )
}







