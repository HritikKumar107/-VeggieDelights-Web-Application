import { Link } from "react-router-dom";
import { useEffect } from "react";
import {db,storage} from './Firebase'
import {collection, addDoc, Timestamp, snapshotEqual} from 'firebase/firestore'
import { useState, CSSProperties } from "react";
import {useNavigate} from "react-router-dom"
import { getDownloadURL, ref, uploadBytesResumable } from 'firebase/storage'

export default function AddCategory(){

    const[categoryname,setCategoryName] = useState('')
    const [taskcompletionStatus] = useState('Completed')
    const [file, setFile] = useState(null)
    const [percent, setPercent] = useState(false)
    const [imageUrl, setImageUrl] = useState(null)
    const [fileName, setFileName] = useState(null)

    const handleform = async (data) =>{
        data.preventDefault()
        uploadFile()
    }

    const uploadFile = () => {
        if (!file) {
            alert("Please upload an image first!");
        }
        console.log("File",file)
        console.log("File Name",file.name)

        const fileName = `${Date.now()}-${file.name}`
        const storageRef = ref(storage, `/files/${fileName}`);

        const uploadTask = uploadBytesResumable(storageRef,file);

        uploadTask.on(
            "state_changed",
            (snapshot) => {
                const percent = Math.round(
                    (snapshot.bytesTransferred / snapshot.totalBytes) * 100
                );
                setPercent(percent);
            },
            (err) => console.log(err),() => {
                getDownloadURL(uploadTask.snapshot.ref).then
                ((url) => {
                    console.log("URL",url);
                    setFileName(fileName)
                    setImageUrl(url)
                });
            }
        );
    };

    const saveDate = async () => {
        try{
            await addDoc(collection(db, 'Category'),{
                categoryname : categoryname,
                Image : imageUrl,
                fileName : fileName,
                taskcompletionStatus : taskcompletionStatus,
                created : Timestamp.now()
            })
            alert("Submitted")
        } catch (err) {
            alert(err)
        }
    }

    useEffect(() => {
        if (!! imageUrl)
            saveDate()
    },[imageUrl])
    
    return(
        <>
        <div className="container-fluid page-header wow fadeIn" data-wow-delay="0.1s">
            <div className="container">
                <h1 className="display-3 mb-3 animated slideInDown">Add Category</h1>
                <nav aria-label="breadcrumb animated slideInDown">
                    <ol className="breadcrumb mb-0">
                        <li className="breadcrumb-item"><Link className="text-body" to={'/home'}>Home</Link></li>
                        <div className="breadcrumb-item nav-item dropdown">
                            <a className="text-body dropdown-toggle" data-bs-toggle="dropdown" href="#">Pages</a>
                            <div className="dropdown-menu m-0">
                                <Link to={'/blog_grid'} className="dropdown-item">Blog Grid</Link>
                                <Link to={'/features'} className="dropdown-item">Our Features</Link>
                                <Link to={'/testimonial'} className="dropdown-item">Testimonial</Link>
                                <Link to={'/error'} className="dropdown-item">404 Page</Link>
                            </div>
                        </div>
                        <li className="breadcrumb-item text-dark active" aria-current="page">Add Category</li>
                    </ol>
                </nav>
            </div>
        </div>

        <div className="container-xxl py-6">
            <div className="container">
                <div className="section-header text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style={{'maWidth': '500px'}}>
                    <h1 className="display-5 mb-3">Add Category</h1>
                </div>
                <form data-wow-delay="0.1s" onSubmit={handleform}>
                    <div className="row g-3 ">
                        <div className="col-md-12">
                            <div className="form-floating">
                                <select style={{'borderRadius': '50px'}} onChange={(data) => { setCategoryName(data.target.value)}} className="form-control pb-1 bg-light" id="name">
                                <option selected disabled defaultValue={"Select your category"}>Select your category</option>
                                <option defaultValue={"Fruits"}>Fruits</option>
                                <option defaultValue={"Vegetables"}>Vegetables</option>
                                </select>
                                <label for="name">Category Name</label>
                            </div>
                        </div>
                        <div className="col-md-12">
                            <div className="form-floating">
                                <input type="file" style={{'borderRadius': '50px'}} className="form-control" id="email"  onChange={(data) => setFile(data.target.files[0])}/>
                                <label for="image"> Category Images</label>
                                <p className="ms-3">{percent} "% done"</p>
                            </div>
                        </div>
                        <div className="col-md-12">
                            <button className="btn btn-primary rounded-pill py-3 px-5 fs-4" type="submit">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        </>
    )
}